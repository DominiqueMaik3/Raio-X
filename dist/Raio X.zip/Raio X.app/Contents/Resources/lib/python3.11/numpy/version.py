
version = "1.26.0"
__version__ = version
full_version = version

git_revision = "d35cd07ea997f033b2d89d349734c61f5de54b0d"
release = 'dev' not in version and '+' not in version
short_version = version.split("+")[0]
